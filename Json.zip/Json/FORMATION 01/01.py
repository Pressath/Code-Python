import json

file = "01_names.json"

with open("01_names.json", "r") as json_file:
    data = json.load(json_file)
    name_data = data['names']

    for i in name_data:
        name =i['firstname']
        age = i['age']
        print(name, age)