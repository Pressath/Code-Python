from PIL import Image

#img = Image.open('ressource/rose.jpg').rotate(30)
img = Image.open('ressource/rose.jpg')
img = img.rotate(60, expand = True, fillcolor = 'green', resample = Image.BICUBIC, center=(100,100))
img.show()