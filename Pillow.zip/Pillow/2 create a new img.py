from PIL import Image

img = Image.new('RGB',(255,255),(0,255,58))
img2 = Image.new('RGB',(500,255),'yellow')
img2.show()
'''
new(
    mode: _Mode,
    size: tuple[int, int],
    color: _Color = 0
)
'''