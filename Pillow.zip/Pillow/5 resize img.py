from PIL import Image

img = Image.open('ressource/couple.jpg')
print(img.width, img.height)
om = img.resize(int(img.width/2), int(img.height/2),resample=Image.LANCZOS)
om.show()