# importation du module Image
from PIL import Image

img = Image.open('ressource/couple.jpg')
print(img) # print the image object return by this function 'open()'
img.show() # print the