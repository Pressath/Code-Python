from PIL import Image

img1 = Image.open('ressource/couple.jpg')
img2 = Image.open('ressource/rose.jpg')

img = Image.blend(img1, img2, alpha = 0.5)
img.show()
